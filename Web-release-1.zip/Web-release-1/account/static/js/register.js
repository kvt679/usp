$(function () {
    var val = $(".helptext").css('color', "#434a52");
});