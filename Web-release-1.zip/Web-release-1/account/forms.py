from django import forms
from django.contrib.auth.models import User

from .models import Shipping


class LoginForm(forms.ModelForm):
    username = forms.CharField(label='',
                               widget=forms.TextInput(attrs={'placeholder': 'Email', 'class': 'form-control'}))
    password = forms.CharField(label='',
                               widget=forms.PasswordInput(attrs={'placeholder': 'Email', 'class': 'form-control'}))


class UserRegistrationForm(forms.ModelForm):
    email = forms.EmailField(max_length=200, required=True, label='', widget=forms.EmailInput(
        attrs={'placeholder': 'Email', 'class': 'form-control'}))
    password = forms.CharField(label='', widget=forms.PasswordInput(
        attrs={'placeholder': 'Password', 'class': 'form-control'}))
    password2 = forms.CharField(label='', widget=forms.PasswordInput(
        attrs={'placeholder': 'Re-Enter Password', 'class': 'form-control'}))

    class Meta:
        model = User
        fields = ('username', 'first_name', 'email')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),

        }
        labels = {
            'username': '',
            'first_name': '',
            'email': '',
        }

    def clean_password2(self):
        cd = self.cleaned_data
        if cd['password'] != cd['password2']:
            raise forms.ValidationError('Passwords don\'t match.')
        return cd['password2']

    def clean_email(self):
        email = self.cleaned_data['email']
        id, uni = email.split("@")
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Please use another Email. This email is already taken')

        # if uni in ["student.usp.ac.fj", "student.fnu.ac.fj"]:
        return email
        # raise forms.ValidationError("Please enter your student email.")


class UserEditForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.TextInput(attrs={'class': 'form-control'}),
        }


class ShippingForm(forms.ModelForm):
    class Meta:
        model = Shipping
        fields = '__all__'
        widgets = {
            'user': forms.TextInput(attrs={'type': 'hidden'}),
            'payment_method': forms.Select(attrs={'class': 'form-control'}),
            'receiving_method': forms.TextInput(attrs={'type': 'hidden'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),

        }
        labels = {
            'payment_method': 'Payment Method',
            # 'receiving_method': 'Receiving Method',
            'phone_number': 'Phone Number',
            'location': 'Delivery Location',
        }

    def clean_payment_method(self):
        user = self.cleaned_data['user']
        payment = self.cleaned_data['payment_method']
        if not user.payroll.active:
            raise forms.ValidationError('To use Payroll deduction as payment method. Register first.')
        return payment

# class PayrollForm(forms.ModelForm):
#     class Meta:
#         model = Payroll
#         fields = ('user', 'employee_id', 'deduction_amount')
#         widgets = {
#             'user': forms.TextInput(attrs={'type': 'hidden'}),
#             'employee_id': forms.TextInput(attrs={'class': 'form-control'}),
#             'deduction_amount': forms.TextInput(attrs={'class': 'form-control'}),
#
#         }
#         labels = {
#             'employee_id': 'Employee ID',
#             # 'receiving_method': 'Receiving Method',
#             'deduction_amount': 'Deduction Amount',
#         }
