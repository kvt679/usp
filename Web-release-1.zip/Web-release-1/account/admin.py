from django.contrib import admin

from .models import *


# Register your models here.

@admin.register(Shipping)
class ShippingAdmin(admin.ModelAdmin):
    list_display = ['user', 'payment_method', 'receiving_method', 'phone_number', 'location']
