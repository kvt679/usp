from celery import shared_task
from django.contrib.auth.models import User
from django.core.mail import send_mail


@shared_task
def confirm_email(user_id, subject, message):
    """
    Task to send an e-mail notification
    to confirm email address.
    """
    user = User.objects.get(id=user_id)
    mail_send = send_mail(subject, message, 'admin@myshop.com', [user.email])
    print("hello from confirm email views in accounts")

    return mail_send
