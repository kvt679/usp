from django.conf import settings
from django.core.validators import RegexValidator
from django.db import models
from django.urls import reverse


# Create your models here.

class Shipping(models.Model):
    PAYMENT_METHOD_CHOICE = (
        ('Cash', 'Cash'),
        ('Payroll Deduction', 'Payroll Deduction'),
    )

    ORDER_RECEIVING_CHOICES = (
        ('Pick-Up', 'Pick-Up'),
        ('Delivery', 'Delivery'),
    )
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

    payment_method = models.CharField(max_length=20,
                                      choices=PAYMENT_METHOD_CHOICE,
                                      default='Cash')

    receiving_method = models.CharField(max_length=20,
                                        choices=ORDER_RECEIVING_CHOICES,
                                        default='Pick-Up')

    phone_regex = RegexValidator(regex=r'^\+?1?\d{7}$',
                                 message="Phone number must be entered in the format: '7654321'. Up to 7 digits "
                                         "allowed.")
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True)  # validators should be a list
    location = models.CharField(max_length=50, default='')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def get_absolute_url(self):
        return reverse('profile-detail',
                       args=[self.user_id])

# class Payroll(models.Model):
#     user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
#
#     employee_id = models.CharField(max_length=50)
#     deduction_amount = models.DecimalField(max_digits=10, decimal_places=2)
#     balance = models.DecimalField(max_digits=10, decimal_places=2)
#
#     created = models.DateTimeField(auto_now_add=True)
#     updated = models.DateTimeField(auto_now=True)
#
#     def get_absolute_url(self):
#         return reverse('payroll',
#                        args=[self.user_id])
