# Create your views here.
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode

from .forms import LoginForm, UserRegistrationForm, UserEditForm
from .forms import ShippingForm
from .models import Shipping
# from rest_framework.response import Response
# from rest_framework.views import APIView
from .tasks import confirm_email
# Log-in
from .tokens import account_activations_token


# Create your views here.


def user_login(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(
                request,
                username=cd['username'],
                password=cd['password']
            )
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponse('Authenticated successfully')
                else:
                    return HttpResponse('Disabled Account')
            else:
                return HttpResponse('Invalid login')
    else:
        form = LoginForm()
    return render(request, 'registration/login.html', {'form': form})


# Sign-up
def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            # Create a new user object but avoid saving it yet
            new_user = user_form.save(commit=False)
            new_user.email = user_form.cleaned_data['email']
            new_user.set_password(user_form.cleaned_data['password'])
            new_user.is_active = False
            new_user.save()

            # Profile.objects.create(user=new_user)
            current_site = get_current_site(request)
            subject = 'Activate your Account'

            message = render_to_string('account/account_activation_email.html', {
                'user': new_user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(new_user.pk)),
                'token': account_activations_token.make_token(new_user),
            })

            # launch asynchronous task
            confirm_email.delay(new_user.id, subject, message)
            # email = EmailMessage(subject, message, to=[new_user.email])
            # email.send()

            return render(request,
                          'account/register_done.html',
                          {'new_user': new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request,
                  'account/register.html',
                  {'user_form': user_form})


def activate(request, uidb64, token, backend='django.contrib.auth.backends.ModelBackend'):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activations_token.check_token(user, token):
        user.is_active = True
        user.save()
        Shipping.objects.create(user=user)
        user.shipping.save()
        # user.save()
        return render(request, 'account/account_activate_successful.html')
    else:
        return render(request, 'account/account_activate_unsuccessful.html')


# profile view code below
@login_required
def shipping_edit(request):
    if request.method == 'POST':
        shipping_form = ShippingForm(
            instance=request.user.shipping,
            data=request.POST,
            files=request.FILES)
        if shipping_form.is_valid():
            payment = shipping_form.cleaned_data['payment_method']
            purchase = shipping_form.save(commit=False)

            print(payment)
            if payment == 'Cash':
                purchase.receiving_method = 'Pick-Up'
            else:

                purchase.receiving_method = 'Delivery'
            purchase.save()
            return redirect(shipping_detail)
    else:
        shipping_form = ShippingForm(instance=request.user.shipping)

    return render(request,
                  'account/profile_edit.html',
                  {'profile_form': shipping_form,
                   'section': 'account'})


@login_required
def shipping_detail(request):
    shipping_form = request.user.shipping

    return render(request, 'account/shipping-detail.html', {'shipping_form': shipping_form,
                                                            'section': 'account'})


@login_required
def user_info(request):
    user = request.user
    return render(request, 'account/user_info.html', {'user': user, 'section': 'account'})


@login_required
def user_edit(request):
    if request.method == "POST":
        user_form = UserEditForm(instance=request.user, data=request.POST)

        if user_form.is_valid():
            user_form.save()
            # messages.success(request, "User info updated successfully")
            return redirect(user_info)
        else:
            messages.error(request, 'Error updating your info')
    else:
        user_form = UserEditForm(instance=request.user)

    return render(request,
                  'account/user_edit.html',
                  {'user_form': user_form, 'section': 'account'})

# @login_required
# def payroll_edit(request):
#
#     if request.method == 'POST':
#         payroll_form = PayrollForm(instance=request.user.payroll, data=request.POST)
#         if payroll_form.is_valid():
#             payroll = payroll_form.save(commit=False)
#             payroll.active = True
#             payroll.save()
#             return redirect(profile_edit)
#     else:
#         payroll_form = PayrollForm(instance=request.user.payroll)
#     return render(request,
#                   'account/payroll_form.html',
#                   {'payroll_form': payroll_form,
#                    'section': 'account'})
