from django.contrib.auth import views as auth_views
from django.urls import path, include

from .views import *

urlpatterns = [

    # path('', dashboard, name='dashboard'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('', include('django.contrib.auth.urls')),
    path('register/', register, name='register'),
    path('user-info/', user_info, name='user_info'),
    path('user-edit/', user_edit, name='user_edit'),
    path('activate/<uidb64>/<token>/', activate, name='activate'),
    # profile urls
    path('shipping-datail/', shipping_detail, name='shipping-datail'),
    path('profile-edit/', shipping_edit, name='profile-edit'),

]
