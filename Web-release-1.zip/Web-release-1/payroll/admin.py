# Register your models here.
from django.contrib import admin
from django.http import HttpResponseRedirect

from .models import Requests, Approved, Rejected


@admin.register(Requests)
class RequestsAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'first_name', 'status', 'deduction_amount']
    exclude = ['user']
    readonly_fields = ['employee_id', 'first_name', 'last_name', 'deduction_amount']

    def save_model(self, request, obj, form, change):
        if obj.status == "Approve":
            Approved.objects.create(request_ID=obj)
        elif obj.status == "Reject":
            Rejected.objects.create(request_ID=obj)
        super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.filter(status="")

    # def response_change(self, request, obj):
    #     return redirect('/admin/sales/invoice')
    def response_change(self, request, obj, post_url_continue=None):
        """
        This makes the response go to the newly created
        model's change page without using reverse
        """
        if obj.status == "Reject":
            rej = Rejected.objects.get(request_ID=obj.id)
            return HttpResponseRedirect("../../../rejected/%s" % rej.id)
        return super(RequestsAdmin, self).response_add(request, obj, post_url_continue)


def add_deduction(modeladmin, request, queryset):
    for obj in queryset:
        obj.balance += obj.request_ID.deduction_amount
        obj.save()


add_deduction.short_description = 'Add deduction amount to balance'


@admin.register(Approved)
class ApprovedAdmin(admin.ModelAdmin):
    list_display = ['request_ID', 'balance', 'updated']
    readonly_fields = ['request_ID', 'balance', 'updated', 'created']
    actions = [add_deduction, ]


@admin.register(Rejected)
class RejectedAdmin(admin.ModelAdmin):
    list_display = ['request_ID', 'reason', 'updated', 'created']
    readonly_fields = ['request_ID', 'created', 'updated']
