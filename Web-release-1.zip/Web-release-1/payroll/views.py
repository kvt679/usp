from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from .models import Requests
from .forms import RequestForm


@login_required
def payroll_register(request):
    initial_dict = {
        'user': request.user,
        'first_name': request.user.first_name,
        'last_name': request.user.last_name,
    }
    obj = Requests.objects.all()
    if obj.filter(user=request.user).count():
        register_form = None
    else:
        if request.method == "POST":
            register_form = RequestForm(request.POST)
            if register_form.is_valid():
                register_form.save()

                return redirect('payroll:payroll-detail')
        else:
            register_form = RequestForm(initial=initial_dict)
    return render(request, 'payroll/request_register.html', {'form': register_form})


@login_required
def payroll_detail(request):
    try:
        payroll_form = Requests.objects.get(user=request.user)
    except Requests.DoesNotExist:
        payroll_form = None

    return render(request, 'payroll/request_detail.html', {'form': payroll_form, 'section': 'payment'})
