from django.conf import settings
from django.contrib.auth.models import User
from django.db import models


# Create your models here.


class Requests(models.Model):
    class Meta:
        verbose_name = "Requests"
        verbose_name_plural = "Requests"

    REQUEST_METHOD_CHOICE = (
        ('Approve', 'Approve'),
        ('Reject', 'Reject'),
    )
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="payroll_request", on_delete=models.CASCADE)
    first_name = models.CharField(max_length=40)
    last_name = models.CharField(max_length=40)
    employee_id = models.CharField(max_length=50)
    deduction_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=REQUEST_METHOD_CHOICE, blank=True)

    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.employee_id)


class Approved(models.Model):
    class Meta:
        verbose_name = "Approved"
        verbose_name_plural = "Approved"

    request_ID = models.ForeignKey(Requests, related_name="request_approved", on_delete=models.CASCADE)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    # def get_absolute_url(self):
    #     return reverse('payroll',
    #                    args=[self.user_id])


class Rejected(models.Model):
    class Meta:
        verbose_name = "Rejected"
        verbose_name_plural = "Rejected"

    request_ID = models.ForeignKey(Requests, related_name="request_rejected", on_delete=models.CASCADE)
    reason = models.TextField(blank=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
