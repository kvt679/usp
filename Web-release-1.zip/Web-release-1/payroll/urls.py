from django.urls import path

from .views import payroll_register, payroll_detail

app_name = 'payroll'

urlpatterns = [
    path('', payroll_detail, name='payroll-detail'),
    path('register/', payroll_register, name='payroll-register'),
]
