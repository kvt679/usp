from django import forms
from .models import Requests, Approved, Rejected


class RequestForm(forms.ModelForm):
    class Meta:
        model = Requests
        fields = '__all__'
        widgets = {
            'user': forms.TextInput(attrs={'type': 'hidden'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'employee_id': forms.TextInput(attrs={'class': 'form-control'}),
            'deduction_amount': forms.TextInput(attrs={'class': 'form-control'}),
            'status': forms.TextInput(attrs={'type': 'hidden'}),
        }
        labels = {
            'employee_id': 'Employee ID',
            # 'receiving_method': 'Receiving Method',
            'deduction_amount': 'Deduction Amount',
        }
        # later check if employee id is already in use


