import decimal

from django import forms

from payroll.models import Requests, Approved
from .models import Order


class OrderCreateForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['user', 'first_name', 'last_name', 'email', 'phone_number', 'payment_method', 'location', 'receivable_time',
                  'cost']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.TextInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'payment_method': forms.Select(attrs={'class': 'form-control'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),
            'receivable_time': forms.TextInput(attrs={'class': 'form-control'}),
            'user': forms.TextInput(attrs={'type': 'hidden'}),
            'cost': forms.TextInput(attrs={'type': 'hidden'}),
            # 'created': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def clean_payment_method(self):
        user = self.cleaned_data['user']
        payment = self.cleaned_data['payment_method']
        cost = decimal.Decimal(self.data['cost'])

        if payment == "Payroll Deduction":
            try:
                payroll_form = Requests.objects.get(user=user)
                if payroll_form.status == "Approve":
                    approve = Approved.objects.get(request_ID=payroll_form)
                    if approve.balance < cost:
                        raise forms.ValidationError(
                            "Sorry, Your payroll balance is running low. Please choice other payment method.")
                else:
                    raise forms.ValidationError("Your Payroll deduction has no yet been approved")
            except Requests.DoesNotExist:
                raise forms.ValidationError("To use Payroll deduction as payment method. Register first.")
        return payment

    def clean_cost(self):
        cost = self.cleaned_data['cost']

        return cost
