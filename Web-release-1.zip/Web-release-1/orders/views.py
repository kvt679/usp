from django.utils import timezone

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect

from cart.cart import Cart
from payroll.models import Approved, Requests
from shop.models import Product
from .forms import OrderCreateForm
from .models import OrderItem, Order
from .tasks import order_created


# Create your views here.

@login_required
def order_create(request):
    cart = Cart(request)
    initial_dict = {
        'first_name': request.user.first_name,
        'last_name': request.user.last_name,
        'email': request.user.email,
        'phone_number': request.user.shipping.phone_number,
        'payment_method': request.user.shipping.receiving_method,
        'location': request.user.shipping.location,
        'receivable_time': timezone.now(),
        'user': request.user,
        'cost': float(cart.get_total_price()),
    }

    if request.method == 'POST':
        form = OrderCreateForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            if order.payment_method == "Payroll Deduction":
                obj = Requests.objects.get(user=request.user)
                app = Approved.objects.get(request_ID=obj.id)
                app.balance -= cart.get_total_price()
                app.save()
                order.paid = True

            order.save()
            for item in cart:
                OrderItem.objects.create(order=order,
                                         product=item['product'],
                                         price=item['price'],
                                         quantity=item['quantity'])

            # clear the cart
            cart.clear()
            # launch asynchronous task
            order_created.delay(order.id)
            return render(request, 'orders/order/created.html', {'order': order})

    else:
        form = OrderCreateForm(initial=initial_dict)

    return render(request, 'orders/order/create.html', {'cart': cart, 'form': form})


@login_required
def order_list(request):
    obj = Order.objects.filter(user=request.user)
    return render(request, 'orders/order/orders-list.html', {'obj': obj, 'section': 'order'})


@login_required
def order_detail(request, id):
    obj = get_object_or_404(Order, pk=id)
    obj1 = OrderItem.objects.filter(order_id=id)
    items = []
    for i in obj1:
        pro = Product.objects.get(pk=i.product_id)
        init = {
            "Name":pro.name,
            "Quantity": i.quantity,
            "Price": i.price
        }

        items.append(init)
    return render(request, 'orders/order/orders-detail.html', {'obj': obj, 'items': items, "section": "order"})


@login_required
def order_remove(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if order.status == "Pending":
        if order.payment_method == "Payroll Deduction":
            req = Requests.objects.get(user=request.user)
            app = Approved.objects.get(request_ID=req.id)
            app.balance += order.cost
            app.save()

        order.delete()

    return redirect('orders:order_list')
