from django.contrib import admin

from .models import Order, OrderItem, Accepted, Rejected


# Register your models here.


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    raw_id_fields = ['product']


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'first_name', 'last_name',
                    'paid', 'created', 'updated']

    list_filter = ['paid', 'created', 'updated']
    exclude = ['user', 'accept', 'reject', 'cost']
    readonly_fields = ['first_name', 'last_name', 'email', 'phone_number', 'location', 'receivable_time', 'payment_method', 'created', 'updated']
    inlines = [OrderItemInline]


# @admin.register(Accepted)
# class AcceptedAdmin(admin.ModelAdmin):
#     list_display = ['order_id', 'status', 'created', 'updated']
#     inlines = []
#
#
# @admin.register(Rejected)
# class RejectedAdmin(admin.ModelAdmin):
#     list_display = ['order_id', 'created', 'updated']
#     inlines = []
#
#     # exclude = ['user', 'accept', 'reject']
