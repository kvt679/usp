from django.conf import settings
from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.db import models

# Create your models here.
from django.urls import reverse

from shop.models import Product


class Accepted(models.Model):
    STATUS_METHOD_CHOICE = (
        ('Preparing', 'Preparing'),
        ('Awaiting Pick-Up', 'Awaiting Pick-Up'),
        ('Delivering', 'Delivering'),
        ('Complete', 'Complete'),
    )
    order_id = models.CharField(max_length=10)
    status = models.CharField(max_length=18,
                              choices=STATUS_METHOD_CHOICE,
                              default='Preparing')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)


class Rejected(models.Model):
    order_id = models.CharField(max_length=10)
    reason = models.TextField(blank=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.id)


class Order(models.Model):
    PAYMENT_METHOD_CHOICE = (
        ('Cash', 'Cash'),
        ('Payroll Deduction', 'Payroll Deduction'),
    )

    STATUS_METHOD_CHOICE = (
        ('Pending', 'Pending'),
        ('Approve', 'Approve'),
        ('Reject', 'Reject'),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE,
                             related_name='order_pay')
    accept = models.ForeignKey(Accepted, on_delete=models.CASCADE, related_name='order_accept', blank=True, null=True)
    reject = models.ForeignKey(Rejected, on_delete=models.CASCADE, related_name='order_reject', blank=True, null=True)
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    phone_regex = RegexValidator(regex=r'^\+?1?\d{7}$',
                                 message="Phone number must be entered in the format: '7654321'. Up to 7 digits "
                                         "allowed.")
    phone_number = models.CharField(validators=[phone_regex], max_length=7)  # validators should be a list

    payment_method = models.CharField(max_length=20,
                                      choices=PAYMENT_METHOD_CHOICE,
                                      default='Cash')
    location = models.CharField(max_length=50)
    receivable_time = models.DateTimeField()

    status = models.CharField(max_length=10,
                              choices=STATUS_METHOD_CHOICE,
                              default='Pending')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    paid = models.BooleanField(default=False)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return f'Order {self.id}'

    def get_total_cost(self):
        return sum(item.get_cost() for item in self.items.all())

    def get_absolute_url(self):
        return reverse('orders:order_detail',
                       args=[self.id])


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name='order_items', on_delete=models.CASCADE)

    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return str(self.id)

    def get_cost(self):
        return self.price * self.quantity
