<h1>Web</h1>
<h2>CS415 Project</h2>

<h3>Preinstall Software:</h3>
<ul>
    <li>RabbitMQ - as message broker</li>
    <li>POSTGRESQL - as our database</li>
</ul>


<h3>Environment Setup</h3>
Create an env and install the required packages:
<br>
use requirements.txt file

Run this command in the terminal: 
<br>
```celery -A Web worker -l info```


Then run the django-development server: 
<br>
```python manage.py runserver```
